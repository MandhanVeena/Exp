import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:lucky/constants/constants.dart';
import 'package:lucky/screens/home.dart';
import 'package:provider/provider.dart';
import 'screens/cartScreen/cartStore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  Widget build(BuildContext context) {
    
    return ChangeNotifierProvider(
        create: (context) => MyStore(),
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Exp',
          theme: ThemeData(
            scaffoldBackgroundColor: backgroundColor,
            primaryColor: themeColor,
            textTheme: Theme.of(context).textTheme.apply(bodyColor: textColor),
          ),
          home: HomeScreen(),
        ));
  }
}
