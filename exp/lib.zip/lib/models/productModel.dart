class Product {
  String brand;
  String category;
  String prodId;
  String name;
  List images;
  String quantity;
  String price;
  String fadeprice;
  String description;
  bool stock;
  bool trending;

  Product(
      this.prodId,
      this.name,
      this.images,
      this.price,
      this.quantity,
      this.brand,
      this.category,
      this.description,
      this.fadeprice,
      this.stock,
      this.trending);
}

class Cart {
  Product product;
  int number;

  Cart(this.product, this.number);
}





/*import 'package:flutter/material.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class ProductModel {
  static const String BRAND = 'brand';
  static const String CATEGORY = 'category';
  static const String ID = 'id';
  static const String NAME = 'name';
  static const String PICTURE = 'picture';
  static const String QUANTITY = 'quantity';
  static const String NUMBER = 'number';
  static const String PRICE = 'price';
  static const String DESCRIPTION = 'description';
  static const String OUTSTOCK = 'outstock';
  static const String TRENDING = 'trending';

  String _brand;
  String _category;
  String _id;
  String _name;
  String _picture;
  List _quantity;
  int _number;
  double _price;
  String _description;
  bool _outstock;
  bool _trending;

  String get brand => _brand;
  String get category => _category;
  String get id => _id;
  String get name => _name;
  String get picture => _picture;
  List get quantity => _quantity;
  int get number => _number;
  double get price => _price;
  String get description => _description;
  bool get outstock => _outstock;
  bool get trending => _trending;

  ProductModel.fromSnapshot(DocumentSnapshot snapshot)
      : _brand = snapshot[BRAND],
        _category = snapshot[CATEGORY],
        _description = snapshot[DESCRIPTION],
        _id = snapshot[ID],
        _name = snapshot[NAME],
        _number = snapshot[NUMBER],
        _outstock = snapshot[OUTSTOCK],
        _picture = snapshot[PICTURE],
        _price = snapshot[PRICE],
        _quantity = snapshot[QUANTITY],
        _trending = snapshot[TRENDING];
}*/

