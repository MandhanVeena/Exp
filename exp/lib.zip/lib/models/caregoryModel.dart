/*import 'package:flutter/material.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class CategoryModel {
  static const String ID = 'id';
  static const String NAME = 'catName';
  static const String PICTURE = 'image';
  static const String PRIORITY = 'priority';

  String _id;
  String _name;
  String _picture;

  double _priority;

  String get id => _id;
  String get name => _name;
  String get picture => _picture;

  double get priorirty => _priority;

  CategoryModel.fromSnapshot(DocumentSnapshot snapshot)
      : _id = snapshot[ID],
        _name = snapshot[NAME],
        _picture = snapshot[PICTURE],
        _priority = snapshot[PRIORITY];
}*/
