import 'package:flutter/material.dart';
import 'package:lucky/models/productModel.dart';
import 'package:lucky/screens/products/productServices.dart';

import 'cartHelper.dart';

class MyStore extends ChangeNotifier {
  List<Product> products = [];
  List<Cart> carts = [];
  List<Product> thisCat;
  Cart activeProduct;
  List pro = [];

  //List<Product> get _products => products;
  //List<Cart> get _carts => carts;
  //Product get _activeProduct => activeProduct;

  fetchDatabaseList() async {
    dynamic resultant = await ProductServices().getProducts();
    if (resultant == null) {
      print("unable to retrieve");
    } else {
      pro = resultant;
      for (var item in resultant) {
        products.add(
          Product(
              item['productId'],
              item['name'],
              item['images'],
              item['price'],
              item['quantity'],
              item['brand'],
              item['category'],
              item['description'],
              item['fadeprice'],
              item['stock'],
              item['trending']),
        );
      }
    }
  }

  MyStore() {
    fetchDatabaseList();
    callCart();
    notifyListeners();
  }

  callCart() async {
    List<Map<String, dynamic>> rows = await DatabaseHelper.instance.queryAll();

    for (var i in rows) {
      List img = [];
      img.add(i['images']);
      carts.add(Cart(
          Product("123", i['name'], img, i['price'], i['quantity'], i['brand'],
              i['category'], i['description'], i['fadeprice'], true, true),
          i['number']));
    }
  }

  setActive(Product p) {
    Cart found;
    if (carts != [])
      found = carts.firstWhere((element) => element.product.name == p.name,
          orElse: () => null);

    if (found != null) {
      activeProduct = Cart(found.product, found.number);
    } else
      activeProduct = Cart(p, 0);

    print("Active product");
    print(activeProduct.product.name);
    print(activeProduct.number);
  }

  fetchByCategory(category) {
    thisCat = [];
    for (Product item in products) {
      if (item.brand == category || item.category == category) {
        thisCat.add(item);
      }
    }
  }

  /*getQty(Cart p) async {
    Cart found = carts.firstWhere(
        (element) => element.product.name == p.product.name,
        orElse: () => null);

    for (var c in carts) {
      print(c.product.name);
    }
    print(found.number);
    print(p.number);
    if (found != null)
      return p.number;
    else
      return 0;
  }*/

  addToBasket(Cart p) async {
    Cart found = carts.firstWhere(
        (element) => element.product.name == p.product.name,
        orElse: () => null);
    if (found != null) {
      found.number++;
      p.number = found.number;
      int gt = await DatabaseHelper.instance.update({
        DatabaseHelper.name: p.product.name,
        DatabaseHelper.number: found.number
      });
      print(gt);
    } else {
      p.number = 1;
      carts.add(p);
      await DatabaseHelper.instance.insert({
        DatabaseHelper.name: p.product.name,
        DatabaseHelper.brand: p.product.brand,
        DatabaseHelper.category: p.product.category,
        DatabaseHelper.description: p.product.description,
        DatabaseHelper.price: p.product.price,
        DatabaseHelper.fadeprice: p.product.fadeprice,
        DatabaseHelper.number: p.number,
        DatabaseHelper.quantity: p.product.quantity,
        DatabaseHelper.images: p.product.images[0],
      });
    }

    notifyListeners();
  }

  removeFromBasket(Cart p) async {
    Cart found = carts.firstWhere(
        (element) => element.product.name == p.product.name,
        orElse: () => null);
    if (found != null && found.number == 1) {
      p.number = 0;
      carts.remove(found);
      await DatabaseHelper.instance.delete(p.product.name);
    } else if (found.number != 1) {
      found.number--;
      p.number = found.number;
      await DatabaseHelper.instance.update({
        DatabaseHelper.name: p.product.name,
        DatabaseHelper.number: p.number
      });
    } else {
      print("found null");
    }

    for (var c in carts) {
      print(c.product.name);
      print(c.number);
    }

    notifyListeners();
  }

  getBasketQty() {
    int total = 0;
    for (int i = 0; i < carts.length; i++) {
      total += carts[i].number;
    }

    return total;
  }

  getBasketTotal() {
    int total = 0;
    for (int i = 0; i < carts.length; i++) {
      total += (int.tryParse(carts[i].product.price) ?? 0) * carts[i].number;
    }

    return total;
  }
}
