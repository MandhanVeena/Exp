import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final _dbName = "myCartDatabase11111.db";
  static final _dbversion = 1;
  static final _tableName = "cart1";

  //static final colid = '_id';
  //static final colname = 'name';

  static final brand = 'brand';
  static final category = 'category';
  static final name = 'name';
  static final images = 'images';
  static final quantity = 'quantity';
  static final price = 'price';
  static final fadeprice = 'fadeprice';
  static final description = 'description';

  static final number = 'number';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;

    _database = await _initiateDatabase();
    return _database;
  }

  _initiateDatabase() async {
    Directory directory = await getApplicationDocumentsDirectory();

    String path = join(directory.path, _dbName);
    return await openDatabase(path, version: _dbversion, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $_tableName(
      
         $brand TEXT NOT NULL,
         $category TEXT NOT NULL,
         $name TEXT NOT NULL,
         $images TEXT NOT NULL,
         $quantity TEXT NOT NULL,
         $price TEXT NOT NULL,
         $fadeprice TEXT,
         $description TEXT NOT NULL,
         
         $number INTEGER)
      ''');
  }

  Future<int> insert(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(_tableName, row);
  }

  Future<List<Map<String, dynamic>>> queryAll() async {
    Database db = await instance.database;
    List c = [];
    try {
      c = await db.query(_tableName);
    } catch (e) {
      print(e.toString());
      c = [];
    }
    return c;
  }

  Future<int> update(Map<String, dynamic> row) async {
    Database db = await instance.database;
    String cname = row[name];
    return await db
        .update(_tableName, row, where: '$name=?', whereArgs: [cname]);
  }

  Future<int> delete(String cname) async {
    Database db = await instance.database;
    return await db.delete(_tableName, where: '$name=?', whereArgs: [cname]);
  }
}
