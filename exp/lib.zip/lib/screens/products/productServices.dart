import 'package:flutter/material.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class ProductServices {
  CollectionReference productList =
      FirebaseFirestore.instance.collection('products');

  Future getProducts() async {
    List products = [];
    try {
      await productList.get().then((value) => value.docs.forEach((element) {
            products.add(element.data());
          }));
      return products;
    } catch (e) {
      print(e.toString());
    }
  }
}
