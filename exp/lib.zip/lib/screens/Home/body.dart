import 'package:flutter/material.dart';
import 'package:lucky/constants/constants.dart';
import 'package:lucky/models/caregoryModel.dart';
import 'package:lucky/models/productModel.dart';
import 'package:lucky/screens/Home/brandScrollView.dart';
import 'package:lucky/components/search.dart';
import 'package:lucky/screens/Home/trendingScrollView.dart';
import 'package:lucky/screens/Home/categoryScrollView.dart';
import 'package:lucky/screens/brandsScreen/brandScreen.dart';
import 'package:lucky/screens/catScreen/catScreen.dart';
import 'package:lucky/screens/catScreen/catServices.dart';
import 'package:lucky/screens/products/trendingScreen.dart';
import 'package:sliver_tools/sliver_tools.dart';
import '../../components/appBar.dart';
import 'titleMore.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return CustomScrollView(slivers: [
      MyAppBar(
        name: appName,
      ),
      SliverPinnedHeader(
        child: SearchWidget(),
      ),
      SliverToBoxAdapter(
        child: Column(
          children: [
            TitleMoreWidget(
                title: "Categories",
                press: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => CatScreen()));
                }),
            CategoryScrollView(),
            TitleMoreWidget(
                title: 'Trending',
                press: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => TrendingScreen()));
                }),
            TrendingScrollView(),
            TitleMoreWidget(
                title: 'Brands',
                press: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => BrandScreen()));
                }),
            BrandScrollView(),
          ],
        ),
      ),
    ]);
  }
}
