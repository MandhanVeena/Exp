import 'package:flutter/material.dart';
import 'package:lucky/models/productModel.dart';
import 'package:lucky/screens/catScreen/catServices.dart';
import 'package:lucky/screens/detailsScreen/detailsScreen.dart';
import 'package:lucky/screens/products/productServices.dart';
import 'package:lucky/screens/products/productCard.dart';

class TrendingScrollView extends StatefulWidget {
  TrendingScrollView({Key key}) : super(key: key);

  @override
  _TrendingScrollViewState createState() => _TrendingScrollViewState();
}

class _TrendingScrollViewState extends State<TrendingScrollView> {
  List productList = [];
  List trendingList = [];

  @override
  void initState() {
    super.initState();
    fetchDatabaseList();
  }

  fetchDatabaseList() async {
    dynamic resultant = await ProductServices().getProducts();
    if (resultant == null) {
      print("unable to retrieve");
    } else {
      setState(() {
        productList = resultant;
        for (var item in productList) {
          if (item['trending'] == true) {
            trendingList.add(item);
          }
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Container(
      height: size.height * 0.4,
      margin: EdgeInsets.only(bottom: 30),
      child: GridView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: trendingList.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 0),
          itemBuilder: (context, index) {
            return ProductCard(
              product: Product(
                  trendingList[index]['productId'],
                  trendingList[index]['name'],
                  trendingList[index]['images'],
                  trendingList[index]['price'],
                  trendingList[index]['quantity'],
                  trendingList[index]['brand'],
                  trendingList[index]['category'],
                  trendingList[index]['description'],
                  trendingList[index]['fadeprice'],
                  trendingList[index]['stock'],
                  trendingList[index]['trending']),
            );
          }),
    );
  }
}
