import 'package:flutter/material.dart';

const themeColor = Color(0xFF0C9869);
const textColor = Color(0xFF3C4046);
const backgroundColor = Color(0xFFF9F8FD);
const appName = "Exp";
int total = 0;
List cart = [];
